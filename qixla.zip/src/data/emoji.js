module.exports = {
  x: "<:Failed:1086876721703288872> ",
  fail: "<:Failed:1086876721703288872> ",
  check: "<a:success:936499412933435462> ",
  success: "<a:success:1086876008600309782>",
  cash: "$"
}