module.exports = {
  prefix: "!",
  owners: ["859331352334696468"],
};
